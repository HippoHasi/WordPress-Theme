<?php
/**
* Template Name: Copyright License Page
*
* This is a page template that displays at Pages > Add New > Attributes > Template
* in your admin dashboard for your site license.
*
* @package WordPress
* @subpackage Huhtog
* @since Huhtog 1.0
*/

get_header(); ?>

<div class="wrap">
	
	Huhtog WordPress Theme, Copyright 2019 Hasi <br>
	Huhtog is distributed under the terms of the GNU GPL<br>
	<br>
	Huhtog WordPress Theme, that is derivative work of TwentySeventeen WordPress Theme, is licensed <br>
	under the <a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html" style="color:#235b00;"> GNU General Public License, version 2 or later </a>. That means you are free to download, reuse, <br>
	modify, and distribute any files hosted on Huhtog under the terms of either the GPL version 2 <br> 
	or version 3, and to run Huhtog in combination with any code with any license that is compatible with <br> either versions 2 or 3. <br>
	<br>
	This theme is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without <br> even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the <br>
	<a href="https://wordpress.org/about/license/" style="color:#235b00;"> GNU General Public License </a> for more details. <br>
	<br>
	You should have received a copy of the GNU General Public License along with this theme.  If not, see <a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html" style="color:#235b00;">here</a>. <br>
	<br>
	Huhtog WordPress Theme bundles the following third-party resources: <br>
	<br>
	Unsplash Inc 
	<a href="https://unsplash.com/license" style="color:#235b00;">Unsplash license </a>, all photos published on Unsplash can be used for free. You can use them for <br>commercial and noncommercial purposes. <br>
	Source: https://unsplash.com/ <br>
	<br>
	SCALABLE VECTOR GRAPHICS (SVG), <a href="https://www.w3.org/TR/2009/REC-SVG11-20090303/copyright-notice.html" style="color:#235b00;"> Copyright © 2002 </a> World Wide Web Consortium <br>
	Source: https://www.w3.org/TR/SVG2/

</div>

<?php get_footer(); ?>